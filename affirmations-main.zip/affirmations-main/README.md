# affirmations
A simple web app that shows random affirmations from a pre-determined list.
